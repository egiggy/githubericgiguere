<?php 
/**
 * 404 page
 */
get_header();?>
<?php include (TEMPLATEPATH.'/get-option.php');?>
		<div id="page">
			<div id="container">
				<div class="page-wrapper-full">
					<div class="h220">
							<div class="space h10"></div>
							<div class="red-box"><strong>Sorry</strong><br>The page you are finding seem doesn't exist.</div>
					</div>
				</div>
			</div>
		</div>
<?php get_footer();?>