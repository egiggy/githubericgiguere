<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=<?php echo str_replace(" ","+",$sdt_heading_font);?>"/>

<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=<?php echo str_replace(" ","+",$sdt_caption_font);?>"/>

<?php if($sdt_body_font != "Default"): ?>
<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=<?php echo str_replace(" ","+",$sdt_body_font);?>"/>
<?php endif ?>

<link rel="stylesheet"  href="<?php echo get_template_directory_uri();?>/fonts/dejavuItalic/stylesheet.css" type="text/css"  media="screen"/>

<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans"/>

<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=PT+Serif"/>
