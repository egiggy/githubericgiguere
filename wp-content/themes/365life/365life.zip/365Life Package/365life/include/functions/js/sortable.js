jQuery(document).ready(function() {
		jQuery( "#sortable" ).sortable({
			placeholder: "ui-state-highlight"
		});
		jQuery( "#sortable" ).disableSelection();
		});
});